package modelo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ConjuntoLetrasTeste {

	private List<Character> listaTeste;
	
	public void ConjuntoDePalavras(){
		 listaTeste = new ArrayList<Character>(Arrays.asList('s', 'n', 'a', 'i', 'e', 'o'));
	}
	

	public boolean equals(List<Character> listaRecebida) {
		
		boolean diferente = false;		
		
		for (int i = 0; i < listaTeste.size(); i++) {
			if(listaTeste.get(i).equals(listaRecebida.get(i)))
				diferente = diferente || false;
			else
				diferente = true;
		}
		return !diferente;
	}


//    public boolean equals(Object obj) {
//    	   
//        if (obj == null)
//               return false;
//        if (this.getClass() != obj.getClass())
//               return false;
//        String name = obj.toString();
//        return this.toString().equals(name);
//
//  }
	
    public int hashCode() {
        return this.toString().hashCode();
  }
	
}
