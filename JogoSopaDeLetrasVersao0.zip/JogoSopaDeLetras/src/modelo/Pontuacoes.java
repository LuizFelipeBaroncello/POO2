package modelo;

public class Pontuacoes {

}
