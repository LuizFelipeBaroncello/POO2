package modelo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class ConjuntoDePalavras {

	private List<List> conjuntoComConjutosdeLetras;
	private List<String> conjuntoPalavrasDerivadasDeAnseio;
	private List<Character> conjuntoLetrasAnseio;
	private Random random;
	private Map<List<Character>, List<String>> mapaLetras;
	
	private List<Character> conjuntoLetrasSelecionadas;
	
	public ConjuntoDePalavras(){
		 random = new Random();
		 mapaLetras = new HashMap<List<Character>, List<String>>();
		 mapaLetras.put(conjuntoLetrasAnseio, conjuntoPalavrasDerivadasDeAnseio);
		 
		 conjuntoLetrasAnseio = new ArrayList<Character>(Arrays.asList('s', 'n', 'a', 'i', 'e', 'o'));
		 conjuntoPalavrasDerivadasDeAnseio = new ArrayList<String>(Arrays.asList("anseio", "ensaio", "saneio", "sanei", "sino",
				 												"seno", "seio", "soei", "anos", "asno", "sano", "saio", "soai", 
				 												"anis", "sina", "nos", "sei", "aos"));
		 		 
		 conjuntoComConjutosdeLetras = new ArrayList<List>(Arrays.asList(conjuntoLetrasAnseio));
	}

	public List<Character> sorteiaLetras(){
		conjuntoLetrasSelecionadas = conjuntoComConjutosdeLetras.get(random.nextInt(conjuntoComConjutosdeLetras.size()));
		return conjuntoLetrasSelecionadas;
	}
	
	public List<String> retornaConjuntoPalavras(){
		return mapaLetras.get(conjuntoLetrasSelecionadas);
	}
	
	public List<Character> getLetrasJogo(){
		return conjuntoLetrasSelecionadas;
	}
	
	public int retornaNumPalavrasComTresLetras(){
		int numeroDePalavras = 0;
        if ( mapaLetras.containsKey( conjuntoLetrasAnseio ) ) {
            System.out.println("Valor da Chave "+ conjuntoLetrasSelecionadas +
             " = "+mapaLetras.get(conjuntoLetrasSelecionadas));             
           }else{
                  System.err.println("Chave n�o existe");
           }
		for (int i = 0; i < mapaLetras.get(conjuntoLetrasSelecionadas).size(); i++) {
			int numeroDeLetras = mapaLetras.get(conjuntoLetrasSelecionadas).get(i).length();
			if(numeroDeLetras == 3)
				numeroDePalavras++;
		}
		return numeroDePalavras;
	}
	
}