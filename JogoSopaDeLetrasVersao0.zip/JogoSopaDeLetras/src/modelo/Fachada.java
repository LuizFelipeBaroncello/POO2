package modelo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Fachada {

	private Random random;
	private List<String> conjuntoSelecionadoDePalavras;
	private List<String> conjuntoPalavrasQueAindaVaoParaOJogo;
	private List<String> conjuntoPalavrasEmJogo;//
	private ConjuntoDePalavras conjuntoDePalavras;

	public Fachada() {
		conjuntoDePalavras = new ConjuntoDePalavras();
		conjuntoDePalavras.sorteiaLetras();
	}

//	public verificaChute(String chute){
//		
//	}

	public Character retornaLetraEmJogo(int indice) {
		return conjuntoDePalavras.getLetrasJogo().get(indice);
	}

	public int retornaNumPalavrasComTresLetras(){
		return conjuntoDePalavras.retornaNumPalavrasComTresLetras();
	}
	
//	public int retornaNumPalavrasComQuatroLetras() {
//
//	}
//
//	public int retornaNumPalavrasComCincoLetras() {
//
//	}
//
//	public int retornaNumPalavrasComSeisLetras() {
//
//	}
//
//	public String retornaPalavra(int quantidadeLetras){
//		
//	}	

}