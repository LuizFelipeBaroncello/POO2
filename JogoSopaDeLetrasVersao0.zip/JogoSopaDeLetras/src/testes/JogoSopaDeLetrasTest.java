package testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import modelo.ConjuntoDePalavras;
import modelo.Fachada;


public class JogoSopaDeLetrasTest {

	private Fachada fachada;
	
	@Before
	public void setup() throws Exception{
		fachada = new Fachada();
	}

	@Test 
	public void testaSeNumeroDePalavrasComTresLetrasEstaCerto() {
		assertEquals(3, fachada.retornaNumPalavrasComTresLetras());	
	}

}
